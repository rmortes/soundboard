import{s as o}from"../chunks/_layout.e4a84b88.js";export{o as ssr};
