import{default as t}from"../entry/error.svelte.b41236cd.js";export{t as component};
