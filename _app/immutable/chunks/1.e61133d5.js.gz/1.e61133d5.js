import{default as t}from"../entry/error.svelte.2a496826.js";export{t as component};
