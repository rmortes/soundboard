import{default as t}from"../entry/_page.svelte.236217fc.js";export{t as component};
