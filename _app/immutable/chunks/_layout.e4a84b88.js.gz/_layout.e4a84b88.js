const e=!1,o=Object.freeze(Object.defineProperty({__proto__:null,ssr:!1},Symbol.toStringTag,{value:"Module"}));export{o as _,e as s};
